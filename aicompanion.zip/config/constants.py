from __future__ import annotations

APP_NAME = "Arona"
VERSION = "1.5.2"
MODEL_NAME = "gemini-2.5-flash"
TTS_MODEL_NAME = "gemini-2.5-flash-preview-tts"
TTS_VOICE_NAME = "Zephyr"
STT_MODEL_SIZE = "medium"
EPHEMERAL_CONTEXT_MEMORY_LIMIT = 10

LOG_DIR = "logs"
LOG_FILE = "app.log"
LOG_LEVEL = "INFO"
LOG_ROTATION = "1 MB"
LOG_RETENTION = "7 days"

VTUBE_STUDIO_URL = "ws://localhost:8001"
VTUBE_PLUGIN_NAME = "Arona Companion"
VTUBE_PLUGIN_DEVELOPER = "Kepin"
VTUBE_TOKEN_PATH = "config/vtube_token.json"
VTUBE_MODEL_CONFIG_PATH = "config/vtube_model_config.json"
VTUBE_RECONNECT_INTERVAL = 5.0

LIPSYNC_WINDOW_MS = 50
LIPSYNC_SILENCE_THRESHOLD = 0.05
LIPSYNC_GAIN = 1.4

IDLE_BLINK_MIN_INTERVAL = 4.0
IDLE_BLINK_MAX_INTERVAL = 9.0
IDLE_BLINK_DURATION = 0.15
IDLE_DOUBLE_BLINK_CHANCE = 0.1
IDLE_BREATHING_CYCLE_SECONDS = 4.0
IDLE_BREATHING_AMPLITUDE = 0.5

VISION_MODEL_NAME = "gemini-2.5-flash"
VISION_DEFAULT_TTL = 30.0
# v1.5.2 §10/§45: konstanta runtime statis, BUKAN field Settings yang bisa
# diedit — spec eksplisit melarang bikin VisionIntervalConfig baru hanya
# demi GUI di milestone ini.
VISION_AUTO_INTERVAL = 30.0

ROUTINE_TIMEZONE = "Asia/Jakarta"

INITIATIVE_THRESHOLD = 50.0
INITIATIVE_MAX_PER_HOUR = 3
INITIATIVE_MAX_PER_DAY = 10
INITIATIVE_COOLDOWN_MINUTES = 45.0